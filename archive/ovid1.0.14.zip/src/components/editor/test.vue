


<script>
export default {
  data: () => ({
    items: [
      { title: "Home", icon: "dashboard", callback: doSomething },
      { title: "About", icon: "question_answer", callback: doSomethingElse }
    ]
  })
};
</script>
