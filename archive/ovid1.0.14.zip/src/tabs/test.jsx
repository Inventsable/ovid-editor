app.activeDocument.XMPString


