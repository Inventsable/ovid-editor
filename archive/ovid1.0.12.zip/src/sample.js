var msg = "hello";

function sayHello() {
  return alert(msg);
}
