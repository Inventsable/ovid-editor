let something = ['Test string', 'Test again']

something.forEach(som => {
    alert(`my text is: ${som}`)
})

alert('Hello there')